const axios = require('axios')
const { response } = require('express')

module.exports = {
    async buscaCep(req, res) {
        try {
            const { cep } = req.params
            const resultcep = await axios.get('https://viacep.com.br/ws/'+cep+'/json/')
            if(resultcep){
                res.json(resultcep.data)
            }
        } catch (error) {
            res.json(error)
        }

    }
}