const express = require('express');
const { route } = require('express/lib/application');
const routes = express.Router();
// import all controllers
const produto = require('../controller/Produto_Controller')
const cliente = require('../controller/Cliente_Controller')
const cep = require('../util/buscaCep')

routes.get('/',(req,res)=>{
    res.json({messagem:'Hello World'})
})

//Rotas dos clientes
routes.post('/cliente', cliente.create);
routes.get('/cliente', cliente.findAll);
routes.get('/cliente/:id', cliente.findOne);
routes.put('/cliente', cliente.update);
routes.delete('/cliente/:id', cliente.delete);

//Rotas dos produtos
routes.post('/produto', produto.create);
routes.get('/produto', produto.findAll);
routes.get('/produto/:id', produto.findOne);
routes.put('/produto', produto.update);
routes.delete('/produto/:id', produto.delete);

//Rota CEP
routes.get('/cep/:cep', cep.buscaCep);

module.exports = routes;
