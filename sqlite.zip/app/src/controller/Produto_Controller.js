const Produto = require('../model/Produto_Model')
const database = require('../config/db')


module.exports = {
    async findAll(req, res) {
        try {
            const produto = await Produto.findAll()
            res.json(produto)
        } catch (error) {
            res.json(error)
        }

    },
    async findOne(req, res) {
        try {
            const { id } = req.params
            console.log(id)
            const produto = await Produto.findByPk(id)
            if (produto) {
                res.json(produto)
            } else {
                res.json({ messagem: "Produto não encontrado!" })
            }
        } catch (error) {
            res.json(error)
        }


    },
    async create(req, res) {
        try {
            const sqlscript = await database.sync();
            if (sqlscript) {
                console.log("DataBase Criado!")
            }
            const obj = req.body
            const produto = await Produto.create(obj)
            if (produto) {
                res.json({ messagem: 'Produto salvo com sucesso!' })
            } else {
                res.json({ messagem: 'Erro ao salvar produto!' })
            }

        } catch (error) {
            res.json(error)
        }

    },
    async update(req, res) {
        const { id, nome, preco, descricao } = req.body

        const dados = { nome, preco, descricao }

        const produto = await Produto.findByPk(id)

        if (produto) {

            produto.nome = dados.nome
            produto.preco = dados.preco
            produto.descricao = dados.descricao

            const updateSalve = await produto.save()

            res.json(updateSalve)

        } else {
            res.json({ messagem: "Alteração não realizada!" })
        }

    },
    async delete(req, res) {
        try {
            const { id } = req.params
            const produto = await Produto.findByPk(id)
            if (produto) {
                produto.destroy();
                res.json({ data: { produto }, messagem: "Produto excluido com sucesso" })
            }
        } catch (error) {
            res.json(error)
        }

    }
}