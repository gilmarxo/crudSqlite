const Sequelize = require('sequelize');
const database = require('../config/db');

const Produto = database.define('cliente', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    nome: {
        type: Sequelize.STRING,
        allowNull: false
    },
    telefone: {
        type: Sequelize.STRING
    },
    email:{
        type: Sequelize.STRING
    }
})

module.exports = Produto;